# Privacy Policy

**We do not collect or store any information.**

While you are connected to a PeerJS server, your IP address, randomly-generated
client ID, and signalling data are kept in the server's memory.  With default
settings, the server will remove this information from memory 60 seconds after
you stop communicating with the service.  (See the
[`alive_timeout`](https://github.com/peers/peerjs-server#config--cli-options)
setting.)
